---
catalogId: "BTC.2015.001"
title: "The BitLicense"
deck: "The first time a government tried to draw a regulatory perimeter around bitcoin."
era: "The Long Wait"
status: "Living"
type: "Regulation"
date: 2015-06-24
creator: "New York State Department of Financial Services"
sourcePlatform: "23 NYCRR Part 200"
locked: true
heroImage: "/images/entries/bitlicense.png"
heroImageCaption: "The official BitLicense regulation, NYDFS 23 NYCRR Part 200."
heroImageCredit: "New York State Department of Financial Services"
sources:
  - url: "https://www.dfs.ny.gov/industry_guidance/regulations/23nycrr200"
    label: "NYDFS — 23 NYCRR Part 200, Virtual Currencies"
  - url: "https://www.coindesk.com/policy/2015/06/03/new-yorks-final-bitlicense-rules-text-and-analysis/"
    label: "CoinDesk — New York's final BitLicense rules: text and analysis"
related:
  - "BTC.2011.001"
  - "BTC.2011.002"
---
On June 24, 2015, the New York State Department of Financial Services finalized a regulatory framework called the BitLicense. The rules ran to forty-four pages and required any business engaged in *virtual currency business activity* involving New York or its residents to obtain a license from the state, submit to ongoing examinations, maintain anti-money-laundering programs, file regular reports, and meet capital and cybersecurity standards roughly comparable to those imposed on banks. The licensing fee was five thousand dollars. The compliance cost was, by all credible estimates, considerably more.

The BitLicense was the work of Benjamin Lawsky, the inaugural superintendent of the NYDFS, who had been studying the industry since 2013 and had held two days of public hearings in early 2014. The hearings featured testimony from Cameron and Tyler Winklevoss, Barry Silbert, and a number of senior executives from companies that no longer exist. The draft rule was published in July 2014 and revised twice in response to a comment period that produced over thirty-seven hundred submissions. The final version was less restrictive than the first draft. It was, nevertheless, the most prescriptive cryptocurrency regulation any government had attempted, and its compliance demands were calibrated to firms with substantially more capital than most bitcoin businesses then possessed.

The industry response was a kind of soft secession. Within weeks of the rule's adoption, Kraken, Bitfinex, ShapeShift, Poloniex, BitQuick, GoCoin, and several other operators announced they would no longer serve New York residents. The compliance burden, they said, was not justified by the New York user base. The phenomenon acquired a name — *the Great Bitcoin Exodus* — and produced a roughly two-year period in which New Yorkers had less access to bitcoin services than residents of any other major American jurisdiction. Circle and Coinbase obtained BitLicenses, the first granted in September 2015 and January 2017 respectively. The full list of licensees grew, over the next decade, to roughly thirty firms.

The cultural significance lay less in the specifics of the rule than in what it represented. The BitLicense was the first occasion on which a government treated bitcoin as a regulated industry rather than as a curiosity, a fraud, or a problem to be ignored. Subsequent regulatory actions in other jurisdictions — the European Union's MiCA framework, Japan's Virtual Currency Act, the United States Treasury's various FinCEN advisories — borrowed structurally from the BitLicense's approach. The bitcoin community's response, in turn, established a pattern that would repeat: outraged by what was framed as regulatory overreach, but quietly aware that the existence of regulation, however clumsy, was also a form of recognition.

Lawsky departed the NYDFS the following month, in July 2015 — having announced his exit earlier that spring — and founded a private consultancy that, among other clients, advised cryptocurrency firms on compliance. The optics were widely noted. The rule remains in force. As of 2025 it has been amended several times, most substantively to streamline the application process and to permit certain *self-certification* of new tokens, but the underlying architecture is intact. New York residents still need a licensed counterparty to legally acquire bitcoin. The compliance regime that began with one state's superintendent has, in roughly the form he proposed, become the global default.
